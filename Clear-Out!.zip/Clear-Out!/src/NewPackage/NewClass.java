

package NewPackage;

import programming.*;


public class NewClass extends Emne{
    
    public void meth()
    {
         
    }
    
}
