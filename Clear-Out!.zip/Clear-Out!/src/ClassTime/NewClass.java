/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassTime;

/**
 *
 * @author hi fi
 */
public class NewClass {

    
    {
        System.out.println("aysha kamal tanny");
    }
    NewClass ()
    {
        System.out.println("COnstructir");
    }
    public void pr()
    {
        System.out.println("Main function private");
    }
    public void st()
    {
        System.out.println("Main function Static");
    }
    /*
    public static int stint=100;
    {
        // System.out.println("aysha kamal");    
    }
    int i, $78$ = 90;

    public NewClass()
    {}
    public NewClass(int a) {
        i = a;
        //System.out.println("oka");
    }

    static {
         System.out.println("Static print");
    }

    static {
        // System.out.println("Ki oilo");
    }

    public void ekta() {
        System.out.println("ektat aisi");
    }

    public int ekta(int a) {
        System.out.println("ektat ailam " + a);
        return a;
    }*/

    /*@Override
    protected void finalize() throws Throwable {
        super.finalize(); //To change body of generated methods, choose Tools | Templates.
        System.out.println("finalized");
    }*/
}